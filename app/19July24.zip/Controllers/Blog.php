<?php
namespace App\Controllers;
class Blog extends BaseController {

        public function index()
        {
                echo 'Hello World!';
        }
}