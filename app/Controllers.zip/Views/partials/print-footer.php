<div class="row print-footer" style="display: none;"> 
    <div  class=" col-md-12 col-sm-12">
        <p class="prfooter">
            AT OWNER'S RISK
        </p>
        <div  class=" col-md-12 col-sm-12">
        <p class="prfooter-txt">
            Goods are carried at the owner's risk. The customer (Consignor/Consignee) must make sure that the goods are insured by an Insurance Company. GAE Cargo Movers Pvt. Ltd. Is not held responsible for any kind of loss, damage, hold, leakage, etc. due to any reason. It is further made the GAE Cargo Movers Private Limited is not held responsible foe any Damage or loss due to natural disaster or any act of God, which is beyond the control of the company.

        </p>
        </div>
    </div>
</div>