<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UserTypeModel;
use App\Models\ModulesModel;
use App\Models\UserTypePermissionModel;

class UserType extends BaseController
{
    public function index()
    {
        $userTypeModel = new UserTypeModel();

        $data['usertype_data'] = $userTypeModel->orderBy('id', 'DESC')->paginate(10);

        $data['pagination_link'] = $userTypeModel->pager;

        $data['page_data'] = [
          'page_title' => view( 'partials/page-title', [ 'title' => 'User Types','li_1' => '123','li_2' => 'deals' ] )
          ];
        return view('UserType/index',$data);
    }

    public function add(){
        
        $modules = new ModulesModel();
        $data['modules'] = $modules->where('status','Active')->findAll();

        if($this->request->getMethod()=='POST'){
            $id = $this->request->getVar('id');
            $error = $this->validate([
              'user_type_name'	=>	'required',
            ]);
            
            if(!$error){
              $data['error'] 	= $this->validator;
            }else {
              $usertypeModel = new UserTypeModel();
              $usertypeModel->save([
                'user_type_name'	=>	$this->request->getVar('user_type_name'), 
                'status'  => 'Active',
                'created_at'  =>  date("Y-m-d h:i:sa"),
              ]);

                $usertype_id = $usertypeModel->getInsertID();
                $modules= $this->request->getVar('modules');

                $usertypepermission= new UserTypePermissionModel();
                foreach ($modules as $key => $value) {
                    $userTypeData=[
                            'user_type_id'  =>  $usertype_id,
                            'module_id'     =>  $value,
                            'access'        =>  1,       
                    ];  
                    $usertypepermission->save($userTypeData);   
                }
              $session = \Config\Services::session();
  
              $session->setFlashdata('success', 'User Type added');
              return $this->response->redirect(site_url('/usertype'));
            }
          }

        return view('UserType/create', $data);
    }

    public function edit($id=null){
        $userTypeModel = new UserTypeModel();
        $data['usertype_data'] = $userTypeModel->where('id', $id)->first();
        
        $permissions = new UserTypePermissionModel();
        $data['permissiondata'] = $permissions->where('user_type_id', $id)->findAll();
        $modules = new ModulesModel();
        $data['modules'] = $modules->where('status','Active')->findAll();
        $request = service('request');
        if($this->request->getMethod()=='POST'){
          $id = $this->request->getVar('id');
          $error = $this->validate([
            'user_type_name'	=>	'required',
          ]);
          if(!$error)
          {
            $data['error'] 	= $this->validator;
          }else {
            $usertypeModel = new UserTypeModel();
            $usertypeModel->update($id,[
              'name'	=>	$this->request->getVar('user_type_name'), 
              'status'  => 'Active',
              'updated_at'  =>  date("Y-m-d h:i:sa"),
            ]);
            
            $modules= $this->request->getVar('modules');
            $usertypepermission= new UserTypePermissionModel();
            $usertypepermissiondata = $usertypepermission->where('user_type_id', $id)->delete();
            foreach ($modules as $key => $value) {
                $userTypeData = [ 
                    'user_type_id'  =>  $id,
                    'module_id'     =>  $value,
                    'access'        =>  1,         
                ];
                $usertypepermission->save($userTypeData);
            }
            $session = \Config\Services::session();
            $session->setFlashdata('success', 'User Type updated');
            return $this->response->redirect(site_url('/usertype'));
          }
        }
        return view('UserType/edit', $data);
    }

    public function delete($id){
        $usertypeModel = new UserTypeModel();

        $usertypeModel->where('id', $id)->delete($id);

        $session = \Config\Services::session();

        $session->setFlashdata('success', 'User Type Deleted');

        return $this->response->redirect(site_url('/usertype'));
    }


}
