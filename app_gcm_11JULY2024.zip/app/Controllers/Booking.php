<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\BookingDropsModel;
use App\Models\BookingExpensesModel;
use App\Models\BookingPickupsModel;
use App\Models\BookingsModel;
use App\Models\BookingVehicleLogModel;
use App\Models\CustomerBranchModel;
use App\Models\CustomersModel;
use App\Models\OfficeModel;
use App\Models\PartyModel;
use App\Models\PartytypeModel;
use App\Models\StateModel;
use App\Models\UserModel;
use App\Models\VehicleModel;
use App\Models\VehicleTypeModel;
use CodeIgniter\HTTP\ResponseInterface;

class Booking extends BaseController
{
    public $session;
    public $access;
    public $added_by;
    public $added_ip;
    public $SModel;
    public $VTModel;
    public $VModel;
    public $PModel;
    public $PTModel;

    public $BModel;
    public $BPModel;
    public $BDModel;
    public $BEModel;
    public $OModel;
    public $CModel;
    public $CBModel;
    public $BVLModel;

    public $user;


    public function __construct()
    {
        $this->session = \Config\Services::session();

        $this->user = new UserModel();
        $this->access = $this->user->setPermission();

        $this->added_by = isset($_SESSION['id']) ? $_SESSION['id'] : '0';
        $this->added_ip = isset($_SERVER['REMOTE_ADDR'])  ? $_SERVER['REMOTE_ADDR'] : '';

        $this->SModel = new StateModel();

        $this->VTModel = new VehicleTypeModel();
        $this->VModel = new VehicleModel();
        $this->PModel = new PartyModel();
        $this->PTModel = new PartytypeModel();

        $this->BModel = new BookingsModel();
        $this->BPModel = new BookingPickupsModel();
        $this->BDModel = new BookingDropsModel();
        $this->BEModel = new BookingExpensesModel();
        $this->OModel = new OfficeModel();
        $this->CModel = new CustomersModel();
        $this->CBModel = new CustomerBranchModel();
        $this->BVLModel = new BookingVehicleLogModel();
    }

    public function index()
    {
        if ($this->access === 'false') {
            $this->session->setFlashdata('error', 'You are not permitted to access this page');
            return $this->response->redirect(base_url('/dashboard'));
        } else {
            $this->BModel->select('bookings.*, party.party_name, vehicle.rc_number')
                ->join('customer', 'customer.id = bookings.customer_id')
                ->join('party', 'party.id = customer.party_id')
                ->join('vehicle', 'vehicle.id = bookings.vehicle_id', 'left');

            if ($this->request->getPost('status') != '') {
                $this->BModel->where('bookings.approved', $this->request->getPost('status'));
            }

            $data['bookings'] = $this->BModel->orderBy('bookings.id', 'desc')->findAll();

            $data['pickup'] = $this->BPModel;
            $data['drop'] = $this->BDModel;

            return view('Booking/index', $data);
        }
    }

    public function create()
    {
        if ($this->access === 'false') {
            $this->session->setFlashdata('error', 'You are not permitted to access this page');
            return $this->response->redirect(base_url('/dashboard'));
        } else if ($this->request->getPost()) {

            // echo '<pre>';
            // print_r($this->request->getPost());
            // die;

            $prefix =  $this->user
                ->join('office', 'office.id = users.home_branch')
                ->where('users.id', $this->request->getPost('booking_by'))->first();

            $last_booking = $this->BModel->orderBy('id', 'desc')->first();

            $booking_number = isset($prefix['booking_prefix']) ? $prefix['booking_prefix'] . '/' . $last_booking['id'] + 1 : 'BK/' . $last_booking['id'];

            // save booking
            $booking_id = $this->BModel->insert([
                'booking_number' => $booking_number,
                'booking_for' => $this->request->getPost('booking_for'),
                'office_id' => $this->request->getPost('office_id'),
                'vehicle_type_id' => $this->request->getPost('vehicle_type'),
                'vehicle_id' => $this->request->getPost('vehicle_rc'),
                'customer_id' => $this->request->getPost('customer_id'),
                'customer_branch' => $this->request->getPost('customer_branch'),
                'customer_type' => $this->request->getPost('customer_type'),
                'pickup_date' => $this->request->getPost('pickup_date'),
                'drop_date' => $this->request->getPost('drop_date'),
                'rate_type' => $this->request->getPost('rate_type'),
                'rate' => $this->request->getPost('rate'),
                'booking_by' => $this->request->getPost('booking_by'),
                'booking_date' => $this->request->getPost('booking_date'),
                'guranteed_wt' => $this->request->getPost('guranteed_wt'),
                'advance' => $this->request->getPost('advance'),
                'balance' => $this->request->getPost('balance'),
                'discount' => $this->request->getPost('discount'),
                'bill_to_party' => $this->request->getPost('bill_to'),
                'remarks' => $this->request->getPost('remarks'),
                'added_by' => $this->added_by,
                'added_ip' => $this->added_ip
            ]) ? $this->BModel->getInsertID() : '0';


            if ($booking_id > 0) {

                // save pickups
                foreach ($this->request->getPost('pickup_seq') as $key => $val) {
                    $this->BPModel->insert([
                        'booking_id' => $booking_id,
                        'sequence' => $this->request->getPost('pickup_seq')[$key],
                        'city' => $this->request->getPost('pickup_city')[$key],
                        'state' => $this->request->getPost('pickup_state_id')[$key],
                        'pincode' => $this->request->getPost('pickup_pin')[$key]
                    ]);
                }

                // save drops
                foreach ($this->request->getPost('drop_seq') as $key => $val) {
                    $this->BDModel->insert([
                        'booking_id' => $booking_id,
                        'sequence' => $this->request->getPost('drop_seq')[$key],
                        'city' => $this->request->getPost('drop_city')[$key],
                        'state' => $this->request->getPost('drop_state_id')[$key],
                        'pincode' => $this->request->getPost('drop_pin')[$key]
                    ]);
                }

                // save expenses
                for ($i = 1; $i <= 6; $i++) {
                    if ($this->request->getPost('expense_value_' . $i) > 0) {
                        $this->BEModel->insert([
                            'booking_id' => $booking_id,
                            'expense' => $this->request->getPost('expense_' . $i),
                            'value' => $this->request->getPost('expense_value_' . $i),
                            'bill_to_party' => $this->request->getPost('expense_flag_' . $i) != null ? '1' : '0'
                        ]);
                    }
                }

                $this->session->setFlashdata('success', 'Booking Successfully Added');

                return $this->response->redirect(base_url('booking'));
            } else {
                $this->session->setFlashdata('success', 'Something went wrong. Please try again');
                return $this->response->redirect(base_url('booking/create'));
            }
        } else {

            $data['party'] = $this->PModel->select('party.*')->join('party_type_party_map', 'party_type_party_map.party_id = party.id')
                ->whereIn('party_type_party_map.party_type_id', [1, 2, 5])->groupBy('party.id')->orderBy('party.party_name')->findAll();

            $data['offices'] = $this->OModel->where('status', '1')->findAll();

            $data['vehicle_types'] = $this->VTModel->where('status', 'Active')->findAll();
            $data['employees'] = $this->user->where('usertype', 'employee')->where('status', 'active')->findall();
            $data['states'] =  $this->SModel->findAll();

            $data['customers'] = $this->CModel->select('customer.*, party.party_name')
                ->join('party', 'party.id = customer.party_id')
                ->where('customer.status', '1')
                ->findAll();

            return view('Booking/create', $data);
        }
    }

    public function approve($id)
    {
        if ($this->access === 'false') {
            $this->session->setFlashdata('error', 'You are not permitted to access this page');
            return $this->response->redirect(base_url('/dashboard'));
        } else {

            if ($this->request->getPost()) {

                // echo '<pre>';
                // print_r($this->request->getPost());
                // die;


                // update booking
                $booking_id = $this->BModel->update($id, [
                    'booking_for' => $this->request->getPost('booking_for'),
                    'office_id' => $this->request->getPost('office_id'),
                    'vehicle_type_id' => $this->request->getPost('vehicle_type'),
                    'vehicle_id' => $this->request->getPost('vehicle_rc'),
                    'customer_id' => $this->request->getPost('customer_id'),
                    'customer_branch' => $this->request->getPost('customer_branch'),
                    'customer_type' => $this->request->getPost('customer_type'),
                    'pickup_date' => $this->request->getPost('pickup_date'),
                    'drop_date' => $this->request->getPost('drop_date'),
                    'booking_by' => $this->request->getPost('booking_by'),
                    'booking_date' => $this->request->getPost('booking_date'),
                    'guranteed_wt' => $this->request->getPost('guranteed_wt'),
                    'advance' => $this->request->getPost('advance'),
                    'balance' => $this->request->getPost('balance'),
                    'discount' => $this->request->getPost('discount'),
                    'bill_to_party' => $this->request->getPost('bill_to'),
                    'remarks' => $this->request->getPost('remarks'),
                    'approved_by' => $this->added_by,
                    'approved_ip' => $this->added_ip,
                    'approved_date' => date('Y-m-d h:i:s'),
                    'approved' => $this->request->getPost('approve'),
                ]);

                // delete Drops, Pickups and Expences
                $this->BDModel->where('booking_id', $id)->delete();
                $this->BPModel->where('booking_id', $id)->delete();
                $this->BEModel->where('booking_id', $id)->delete();

                // save pickups
                foreach ($this->request->getPost('pickup_seq') as $key => $val) {
                    $this->BPModel->insert([
                        'booking_id' => $id,
                        'sequence' => $this->request->getPost('pickup_seq')[$key],
                        'city' => $this->request->getPost('pickup_city')[$key],
                        'state' => $this->request->getPost('pickup_state_id')[$key],
                        'pincode' => $this->request->getPost('pickup_pin')[$key]
                    ]);
                }

                // save drops
                foreach ($this->request->getPost('drop_seq') as $key => $val) {
                    $this->BDModel->insert([
                        'booking_id' => $id,
                        'sequence' => $this->request->getPost('drop_seq')[$key],
                        'city' => $this->request->getPost('drop_city')[$key],
                        'state' => $this->request->getPost('drop_state_id')[$key],
                        'pincode' => $this->request->getPost('drop_pin')[$key]
                    ]);
                }

                // save expenses
                for ($i = 1; $i <= 6; $i++) {
                    if ($this->request->getPost('expense_value_' . $i) > 0) {
                        $this->BEModel->insert([
                            'booking_id' => $id,
                            'expense' => $this->request->getPost('expense_' . $i),
                            'value' => $this->request->getPost('expense_value_' . $i),
                            'bill_to_party' => $this->request->getPost('expense_flag_' . $i) != null ? '1' : '0'
                        ]);
                    }
                }


                $this->session->setFlashdata('success', 'Booking Successfully Updated');

                return $this->response->redirect(base_url('booking'));
            }

            $data['party'] = $this->PModel->select('party.*')->join('party_type_party_map', 'party_type_party_map.party_id = party.id')
                ->whereIn('party_type_party_map.party_type_id', [1, 2, 5])->groupBy('party.id')->orderBy('party.party_name')->findAll();

            $data['offices'] = $this->OModel->where('status', '1')->findAll();

            $data['vehicle_types'] = $this->VTModel->where('status', 'Active')->findAll();
            $data['employees'] = $this->user->where('usertype', 'employee')->where('status', 'active')->findall();
            $data['states'] =  $this->SModel->findAll();

            $data['customers'] = $this->CModel->select('customer.*, party.party_name')
                ->join('party', 'party.id = customer.party_id')
                ->where('customer.status', '1')
                ->findAll();

            //for booking data
            $data['booking_details'] = $this->BModel->where('id', $id)->first();
            $data['booking_pickups'] = $this->BPModel->where('booking_id', $id)->findAll();
            $data['booking_drops'] = $this->BDModel->where('booking_id', $id)->findAll();
            $data['booking_expences'] = $this->BEModel->where('booking_id', $id)->findAll();
            $data['vehicle_rcs'] = $this->VModel->where('status', 'active')->findAll();


            return view('Booking/approve', $data);
        }
    }

    public function addPickup()
    {
        $data['states'] =  $this->SModel->findAll();
        $data['index'] = $this->request->getPost('index');
        echo view('Booking/pickup_block', $data);
    }

    public function addDrop()
    {
        $data['states'] =  $this->SModel->findAll();
        $data['index'] = $this->request->getPost('index');
        echo view('Booking/drop_block', $data);
    }

    public function getCustomerType()
    {
        $customer = $this->CModel->where('id', $this->request->getPost('customer_id'))->first();

        $html = '';

        if ($customer) {
            $customer_party_type = explode(',', $customer['party_type_id']);

            $rows = $this->PTModel->whereIn('id', $customer_party_type)->findAll();
            if (count($rows) > 0) {
                foreach ($rows as $row) {
                    $html .= '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                }
            }
        }

        return $html;
    }

    public function getCustomerBranch()
    {
        $html = '';
        $rows = $this->CBModel->where('id', $this->request->getPost('customer_id'))->findAll();
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                $html .= '<option value="' . $row['id'] . '">' . $row['office_name'] . '</option>';
            }
        }
        return $html;
    }

    public function getVehicles()
    {
        $rows =  $this->VModel->where('vehicle_type_id', $this->request->getPost('vehicle_type'))->where('status', 'Active')->findAll();

        $html = '<option value="">Select Vehicle</option>';
        if (count($rows) > 0) {
            foreach ($rows as $row) {
                $html .= '<option value="' . $row['id'] . '">' . $row['rc_number'] . '</option>';
            }
        }

        return $html;
    }

    public function asign_vehicle($id)
    {
        $data['offices'] = $this->OModel->where('status', '1')->findAll();
        $data['vehicle_types'] = $this->VTModel->where('status', 'Active')->findAll();
        $data['customers'] = $this->CModel->select('customer.*, party.party_name')  
            ->join('party', 'party.id = customer.party_id')
            ->where('customer.status', '1')
            ->findAll();
        $data['states'] =  $this->SModel->findAll();
        //for booking data
        $data['booking_details'] = $this->BModel->where('id', $id)->first();
        $data['booking_pickups'] = $this->BPModel->where('booking_id', $id)->findAll();
        $data['booking_drops'] = $this->BDModel->where('booking_id', $id)->findAll();
        $data['booking_expences'] = $this->BEModel->where('booking_id', $id)->findAll();

        $data['vehicle_rcs'] = $this->VModel->select('vehicle.id, vehicle.rc_number, party.party_name')
            ->join('driver_vehicle_map', 'driver_vehicle_map.vehicle_id = vehicle.id')
            ->join('driver', 'driver.id = driver_vehicle_map.driver_id')
            ->join('party', 'party.id = driver.name')
            ->where('driver_vehicle_map.unassign_date', '')
            ->where('vehicle_type_id', $data['booking_details']['vehicle_type_id'])
            ->where('vehicle.status', 'active')->groupBy('vehicle.id')->findAll();



        if ($this->request->getPost()) {
            $this->BModel->update($id, [
                'vehicle_id' => $this->request->getPost('vehicle_rc')
            ]);

            $this->BVLModel->insert([
                'booking_id' => $id,
                'vehicle_id' => $this->request->getPost('vehicle_rc'),
                'assign_by' => $this->added_by
            ]);

            $this->session->setFlashdata('success', 'Vehicle Assigned To Booking');

            return $this->response->redirect(base_url('booking'));
        }




        return view('Booking/vehicle', $data);
    }
}
