<div class="page-wrapper print-header" style="display: none;">
      <div class="content"> 
        <div class="row"> 
          <div  class="prdheader col-md-12 col-sm-12">
            <div><img width="105" height="76" src="<?php echo base_url(); ?>public/assets/img/print-head.png"></div>
            <div > &nbsp;&nbsp;
              <p class="prheader">  
              GAE CARGO MOVERS PRIVATE LIMITED 
              </p>
            </div>
          </div> 
          <div class="col-md-12 col-sm-12">
            <p class="sub-headerpr">
                A-131/2, 2nd Floor, Wazirpur Industrial Area, Delhi- 110052
            </p>
            <p class="sub-headerpr">
                <a href="mailto:gaecargo21@yahoo.com" class="s4" target="_blank">
                    Mobile : 7669027902, EMail :booking@gaegroup.in
                </a>
            </p> 
            <p class="sub-headerpr">
                <span>PAN NO - AAICG9037G</span> &nbsp;&nbsp; <span>GSTIN - 07AAICG9037G1ZF</span> <br/>
                <span>CIN - U63030DL2021PTC378353</span> &nbsp;&nbsp; <span>MSME - UDYAM-DL-06-0016237</span>
            </p>
          </div>
        </div> 
      </div>
    </div>